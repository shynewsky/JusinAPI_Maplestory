#include "stdafx.h"
#include "MainGame.h"
#include "LineMgr.h"
#include "KeyMgr.h"

CMainGame::CMainGame()	
{
}

CMainGame::~CMainGame()
{
	Release();
}

void CMainGame::Initialize()
{
	m_hDC = GetDC(g_hWnd);
	
	CLineMgr::Get_Instance()->Initialize();
}

void CMainGame::Update()
{
	CLineMgr::Get_Instance()->Update();
}

void CMainGame::Late_Update()
{
	CLineMgr::Get_Instance()->Late_Update();
}

void CMainGame::Render()
{
	Rectangle(m_hDC, 0, 0, WINCX, WINCY);

	CLineMgr::Get_Instance()->Render(m_hDC);
}

void CMainGame::Release()
{
	CKeyMgr::Destroy();
	CLineMgr::Destroy();

	ReleaseDC(g_hWnd, m_hDC);
}